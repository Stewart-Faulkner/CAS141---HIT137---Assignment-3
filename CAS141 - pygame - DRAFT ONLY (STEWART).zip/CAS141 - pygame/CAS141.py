import pygame
import random
import sys

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1920, 1080
FPS = 144
GRAVITY = 1
PLAYER_SPEED = 10
JUMP_STRENGTH = 15
PROJECTILE_SPEED = 12
ENEMY_SPEED = 7
CAMERA_LERP_FACTOR = 0.1
HEALTH_BAR_WIDTH = 200
HEALTH_BAR_HEIGHT = 20

# start up pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("CAS141 - pygame")
clock = pygame.time.Clock()

# Setup a textured floor that is repeating and seamless so when sidescrolled remains aesthetic
floor_texture = pygame.image.load('textured floor.jpg')
floor_texture_width = floor_texture.get_width()
floor_texture = pygame.transform.scale(floor_texture, (floor_texture_width, 150))

#get the camera dynamically following player
class Camera:
    def __init__(self):
        self.camera_x = 0

    def apply(self, entity):
        return entity.rect.move(-self.camera_x, 0)

    def update(self, target):
        target_x = target.rect.centerx - SCREEN_WIDTH // 2
        self.camera_x += (target_x - self.camera_x) * CAMERA_LERP_FACTOR

class Player:
    def __init__(self):
        self.rect = pygame.Rect(100, SCREEN_HEIGHT - 150 - 50, 50, 50)
        self.speed = PLAYER_SPEED
        self.jump_strength = JUMP_STRENGTH
        self.velocity_y = 0
        self.is_jumping = False
        self.health = 100
        self.max_health = 100
        self.lives = 3

    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and not self.is_jumping:
            self.velocity_y = -self.jump_strength
            self.is_jumping = True

        # set up gravity, don't jump off map 
        self.rect.y += self.velocity_y
        if self.is_jumping:
            self.velocity_y += GRAVITY
        if self.rect.y >= SCREEN_HEIGHT - 150 - 50:
            self.rect.y = SCREEN_HEIGHT - 150 - 50
            self.is_jumping = False

    def shoot(self):
        return Projectile(self.rect.centerx, self.rect.top)

#set up projectiles
class Projectile:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 10, 5)
        self.speed = PROJECTILE_SPEED

    def move(self):
        self.rect.x += self.speed
        if self.rect.x > SCREEN_WIDTH:
            return False
        return True

#setup enemy 
class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 50, 50)
        self.health = 50

    def move(self):
        self.rect.x -= ENEMY_SPEED

#set up a collectible (still need to add bonus points/scoring systems)
class Collectible:
    def __init__(self, x, y, type):
        self.rect = pygame.Rect(x, y, 30, 30)
        self.type = type  # 'health' or 'life'

class Game:
    def __init__(self):
        self.player = Player()
        self.projectiles = []
        self.enemies = []
        self.collectibles = []
        self.score = 0
        self.level = 1
        self.camera = Camera()
        
        self.font = pygame.font.Font(None, 36)  # Default font
        self.player_name = "CAS141"  # To store player name

    def draw_health_bar(self):
        # Draw title
        title_surface = self.font.render("HP", True, (255, 255, 255))
        screen.blit(title_surface, (10, 10))

        # Draw health bar background
        pygame.draw.rect(screen, (0, 0, 0), (10, 40, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT))

        # Calculate the width of each segment
        segment_width = HEALTH_BAR_WIDTH / 4

        # Determine how many segments should be filled based on health
        segments_filled = max(0, min(4, int(self.player.health / (self.player.max_health / 4))))

        # Draw the filled segments
        for i in range(segments_filled):
            pygame.draw.rect(screen, (255, 0, 0), (10 + i * segment_width, 40, segment_width, HEALTH_BAR_HEIGHT))

        # Draw the outline of the health bar segments
        for i in range(4):
            pygame.draw.rect(screen, (255, 255, 255), (10 + i * segment_width, 40, segment_width, HEALTH_BAR_HEIGHT), 1)

    def draw_player_name(self):
        if self.player_name:
            name_surface = self.font.render(self.player_name, True, (255, 255, 255))
            player_rect = self.camera.apply(self.player)  # Apply camera transformation
            screen.blit(name_surface, (player_rect.x, player_rect.y - 30))  # Adjust y position to be above the player


    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        projectile = self.player.shoot()
                        self.projectiles.append(projectile)

            # Update camera based on player position
            self.camera.update(self.player)

            # Clear the screen
            screen.fill((0, 0, 0))  # Clear the screen to black

            # Draw the repeating textured floor
            floor_offset = -self.camera.camera_x % floor_texture_width
            for i in range(-1, (SCREEN_WIDTH // floor_texture_width) + 2):  # Draw extra to ensure full coverage
                screen.blit(floor_texture, (floor_offset + i * floor_texture_width, SCREEN_HEIGHT - 150))

            # Move player and projectiles
            self.player.move()

            # Move projectiles
            self.projectiles = [p for p in self.projectiles if p.move()]

            # Draw everything
            self.draw_health_bar()  # Call to draw the health bar
            self.draw_player_name()  # Draw player name above the player
            player_rect = self.camera.apply(self.player)
            pygame.draw.rect(screen, (255, 215, 0), player_rect)  # Player
            for p in self.projectiles:
                projectile_rect = self.camera.apply(p)
                pygame.draw.rect(screen, (255, 0, 0), projectile_rect)  # Projectiles
            for enemy in self.enemies:
                enemy_rect = self.camera.apply(enemy)
                pygame.draw.rect(screen, (0, 0, 255), enemy_rect)  # Enemies
            for collectible in self.collectibles:
                collectible_rect = self.camera.apply(collectible)
                pygame.draw.rect(screen, (255, 215, 0), collectible_rect)  # Collectibles

            pygame.display.flip()
            clock.tick(FPS)

# Initialize and run the game
game = Game()
game.run()
pygame.quit()
