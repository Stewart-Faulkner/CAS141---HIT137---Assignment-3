import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Set resolution
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

# Colors
BACKGROUND_COLOR = (0, 0, 0)
PLAYER_COLOR = (46, 207, 255)
FPS = 60

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Game")

class Player:
    def __init__(self):
        self.image = pygame.Surface((50, 50))
        self.image.fill(PLAYER_COLOR)
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = SCREEN_HEIGHT - 70
        self.health = 100

    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= 5
        if keys[pygame.K_RIGHT]:
            self.rect.x += 5

    def shoot(self):
        return Projectile(self.rect.centerx, self.rect.top)

class Projectile:
    def __init__(self, x, y):
        self.image = pygame.Surface((10, 5))
        self.image.fill((255, 0, 0))
        self.rect = self.image.get_rect(center=(x, y))

    def move(self):
        self.rect.x += 10

class Level:
    def __init__(self, player):
        self.player = player
        self.enemies = []
        self.collectibles = []
        self.projectiles = []
        self.create_level()

    def create_level(self):
        # Example enemy creation
        for _ in range(5):
            enemy = Enemy(random.randint(1900, 2100), SCREEN_HEIGHT - 70)
            self.enemies.append(enemy)

    def update(self):
        # Update projectiles
        for projectile in self.projectiles:
            projectile.move()
            if projectile.rect.x > SCREEN_WIDTH:
                self.projectiles.remove(projectile)

        # Update enemies and collectibles as needed
        for enemy in self.enemies:
            enemy.update()  # You need to define this in the Enemy class

    def draw(self):
        for enemy in self.enemies:
            screen.blit(enemy.image, enemy.rect)
        for collectible in self.collectibles:
            screen.blit(collectible.image, collectible.rect)
        for projectile in self.projectiles:
            screen.blit(projectile.image, projectile.rect)

class Enemy:
    def __init__(self, x, y):
        self.image = pygame.Surface((50, 50))
        self.image.fill((255, 0, 0))  # Example color
        self.rect = self.image.get_rect(topleft=(x, y))

    def update(self):
        self.rect.x -= 2  # Move left

def draw_health_bar(player):
    total_segments = 4
    segment_width = 200 // total_segments
    for i in range(total_segments):
        if player.health > (100 / total_segments) * i:
            pygame.draw.rect(screen, (0, 255, 0), (10 + i * segment_width, 10, segment_width, 20))
        else:
            pygame.draw.rect(screen, (255, 0, 0), (10 + i * segment_width, 10, segment_width, 20))

def game_over():
    font = pygame.font.Font(None, 74)
    text = font.render("Game Over", True, (255, 255, 255))
    screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2 - text.get_height() // 2))
    pygame.display.flip()
    pygame.time.wait(3000)
    pygame.quit()
    sys.exit()

def main():
    clock = pygame.time.Clock()
    player = Player()
    levels = [Level(player) for _ in range(3)]
    current_level = 0

    while True:
        screen.fill(BACKGROUND_COLOR)
        player.move()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Restart the game
                    main()  # Be cautious with this
                if event.key == pygame.K_SPACE:  # Shoot
                    projectile = player.shoot()
                    levels[current_level].projectiles.append(projectile)

        levels[current_level].update()  # Update level entities
        levels[current_level].draw()  # Draw enemies, collectibles, and projectiles

        # Draw player
        screen.blit(player.image, player.rect)

        # Draw health bar
        draw_health_bar(player)

        # Check for game over condition
        if player.health <= 0:
            game_over()
            break

        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main()