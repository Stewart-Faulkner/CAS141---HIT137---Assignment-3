
import pygame
import os




pygame.init()


width = 800
height = 460
screen = pygame.display.set_mode((width, height))


#set frame rate
clock = pygame.time.Clock()
FPS = 60

#constant game variables 
gravity = 0.7
tile_size = 20
#define player action variables 
moving_left = False 
moving_right = False
shoot = False

#load images 
bullet_img = pygame.image.load('bullet.png').convert_alpha()


points_coin = pygame.image.load('coin.png').convert_alpha()
health_coin = pygame.image.load('health.png').convert_alpha()

items = {
    'Health' : health_coin, 
    'Points' : points_coin
}


#define colours

BG = (255, 255, 255)
RED =(255, 0, 0)
GREEN = (0, 255, 0)

font = pygame.font.Font('font.ttf', 30)

def draw_text(text, font, text_col, x, y):
    image = font.render(text, True, text_col)
    screen.blit(image, (x, y))


def draw_bg():
    screen.fill(BG)
    

#backround = pygame.image.load('backround.png')

#monster = pygame.image.load('enemy.png')
#monster_rect = monster.get_rect(midbottom = (1200, 650))


#CHARACTERS (HEROS AND ENEMYS)
class Character(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, scale, speed, ammo):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.char_type = char_type
        self.speed = speed
        self.ammo = ammo
        self.start_ammo = ammo
        self.shoot_cooldown = 0
        self.health = 100
        self.points = 0
        self.max_health = self.health
        self.direction = 1
        self.velocity_y = 0
        self.jump = False 
        self.flip = False
        idle = pygame.image.load(f'{self.char_type}.png').convert_alpha()
        self.idle = pygame.transform.scale(idle, (int(idle.get_width() * scale), int(idle.get_height() *scale)))
        self.rect = self.idle.get_rect()
        self.rect.center = (x, y)

    def update(self):
        self.check_alive
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1

        
    def move(self, moving_left, moving_right):
        #reset movement variables 
        dx = 0
        dy = 0

        #assign movement variables for left and right 
        if moving_left:
            dx = -self.speed
            self.flip = True
            self.direction = -1
        if moving_right: 
            dx = self.speed
            self.flip = False
            self.direction = 1

        #jump
        if self.jump == True:
            self.velocity_y = -10
            self.jump = False


        #gravity
        self.velocity_y += gravity 
        if self.velocity_y > 10:
            self.velocity_y = 10
        dy += self.velocity_y

        #check collision with floor
        if self.rect.bottom + dy > 409:
            dy = 409 - self.rect.bottom


        #update rect position
        self.rect.x += dx
        self.rect.y += dy


    #shoot
    def shoot(self):
        if self.shoot_cooldown == 0 and self.ammo > 0:
            self.shoot_cooldown = 20
            bullet = Bullet(self.rect.centerx + (54 * self.direction), self.rect.centery + -5, player_idle.direction)
            bullet_group.add(bullet)
            self.ammo -= 1         


    def check_alive(self):
        if self.health <= 0:
            self.health = 0 
            self.speed = 0
            self.alive = False
        
            


    def draw(self):
        screen.blit(pygame.transform.flip(self.idle, self.flip, False), self.rect)


#COLLECTABLES
class Collectables(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type 
        self.image = items[self.item_type]
        self.rect = self.image.get_rect()
        self.rect.midbottom = (x , y)

    def update(self):
        if pygame.sprite.collide_rect(self, player_idle):  
          if self.item_type == 'Health':
            player_idle.health += 20
            if player_idle.health > player_idle.max_health:
                player_idle.health = player_idle.max_health


          elif self.item_type == 'Points':
            player_idle.points += 100
          self.kill()


#HEALTHBAR
class HealthBar():
    def __init__(self, x, y, health, max_health):
        self.x = x
        self.y = y
        self.health = health      
        self.max_health = max_health

    def draw(self, health):
        self.health = health

        ratio = self.health / self.max_health 

        pygame.draw.rect(screen, RED, (self.x, self.y, 150, 20))
        pygame.draw.rect(screen, GREEN, (self.x, self.y, 150 * ratio, 20))
                   

#BULLETS
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.image = bullet_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = direction

    def update(self):
        #move bullet
        self.rect.x += (self.direction * self.speed)
        #check if bullet has gone off screen
        if self.rect.right < 0 or self.rect.left > 800:
            self.kill()


        for enemy in enemy_group:
            if abs(self.rect.centerx - enemy.rect.centerx) < 20 and \
              abs(self.rect.centerx - enemy.rect.centerx) < 20:
              enemy.health -= 20
              self.kill()
              
        
        if abs(self.rect.centerx - player_idle.rect.centerx) < 20 and \
            abs(self.rect.centerx - player_idle.rect.centerx) < 20:
            player_idle.health -= 20
            self.kill()


        

#sprite groups 
bullet_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
items_group = pygame.sprite.Group()

#create collectable items
health_item = Collectables('Health', 100, 200)
items_group.add(health_item)

points_item = Collectables('Points', 300, 250)
items_group.add(points_item)

#create charachters
player_idle = Character('shoot', 60, 359, 1, 5, 50)
enemy = Character('enemy', 500, 378, 1, 5, 20) 
enemy_group.add(enemy)   

health_bar = HealthBar(10, 10, player_idle.health, player_idle.health)


backround = Character('backround', 400, 230, 1, 5, 0)


run = True
while run == True:

    clock.tick(FPS)

    draw_bg()

    backround.draw()

    health_bar.draw(player_idle.health)

    

    draw_text(f'Points: {player_idle.points}', font, BG, 15, 40)
    

    for enemy in enemy_group:
        enemy.draw()
        enemy.update()

    items_group.update()
    items_group.draw(screen)

    player_idle.update()
    player_idle.draw()
    player_idle.move(moving_left, moving_right)


    #update and draw groups 
    bullet_group.update()
    bullet_group.draw(screen)

    

    #update player actions 
    if player_idle.alive:
        if shoot:
                player_idle.shoot()


    for event in pygame.event.get():

    #game exit

        if event.type == pygame.QUIT:
            run = False

    #keyboard presses

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a and player_idle.alive:
                moving_left = True
            if event.key == pygame.K_d and player_idle.alive:
                moving_right = True
            if event.key == pygame.K_w and player_idle.alive:
                player_idle.jump= True
            if event.key == pygame.K_SPACE and player_idle.alive:
                shoot = True


    #keyboard releases 

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving_left = False
            if event.key == pygame.K_d:
                moving_right = False
            if event.key == pygame.K_SPACE:
                shoot = False




    #screen.blit(backround,(0,0))

 
    


    pygame.display.update()
    

pygame.quit()



